"""
@author: 禾古金
@title: ComfyUX
@nickname: ComfyUX
@description: ComfyUX offers a better user experience for ComfyUI.
"""

class ComfyUX:
    def __init__(self):
        print("😊 ComfyUX.py hello world")